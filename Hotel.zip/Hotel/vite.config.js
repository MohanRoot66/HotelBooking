import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import ViteESLintPlugin from 'vite-plugin-eslint';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    ViteESLintPlugin({
      // Customize ESLint rules here
      overrideConfig: {
        rules: {
          'no-unused-vars': 'warn', // Treat 'no-unused-vars' as a warning
        },
      },
    }),
  ],
});
