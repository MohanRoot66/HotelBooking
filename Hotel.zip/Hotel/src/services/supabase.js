import { createClient } from '@supabase/supabase-js'
const supabaseUrl = 'https://nluicxhzgfjyoehzzwgs.supabase.co'
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sdWljeGh6Z2ZqeW9laHp6d2dzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc2NDQwNTUsImV4cCI6MjAyMzIyMDA1NX0.B0NmgTnC65Bva_D1dXWkM7d9-nObIDJ7Jfbg8v8y8J0"
export const supabase = createClient(supabaseUrl, supabaseKey)